#include "circular.h"

#define max_items2 8 /*Maximum number of items*/
#define buffer_size2 8 /*Size of the buffer*/

int in2 = 0;
int out2 = 0;
int buffer2[buffer_size2];
pthread_mutex_t muteX2;

void *Producer2(void *PNO2)
{   
    int item2;
    for(int i = 0; i < max_items2; i++) {
        item2 = rand(); // To produce random number
        pthread_mutex_lock(&muteX2);
        while (((in2 + 1) % buffer_size2) == out2)
        {
           buffer2[in2] = item2; /*To pass item in buffer*/
           printf("producer number = %d: Insert Item = %d at %d\n", *((int *)PNO2),buffer2[in2],in2);
           in2 = (in2 + 1) % buffer_size2;     
        }
        pthread_mutex_unlock(&muteX2);
    }
}
void *CONSUMER1(void *CNO1)
{   
    int item2=0;
    for(int i = 0; i < max_items2; i++) {
        pthread_mutex_lock(&muteX2);

        while (in2 == out2) 
        {
           item2 = buffer2[out2]; /*Copying data buffer*/
           printf("Consumer %d: Remove Item %d from %d\n",*((int *)CNO1),item2, out2); 
           out2 = (out2 + 1) % buffer_size2;     
        }
        pthread_mutex_unlock(&muteX2);
    }
}

int main()
{   

    pthread_t pro2[8],con2[8];
    pthread_mutex_init(&muteX2, NULL);

    int arr1[8] = {1,2,3,4,5,6,7,8}; //Numbering of producer and customer 

    for(int i = 0; i < 8; i++)
    {
        pthread_create(&pro2[i], NULL, (void *)Producer2, (void *)&arr1[i]);
    }
    for(int i = 0; i < 8; i++) 
    {
        pthread_create(&con2[i], NULL, (void *)CONSUMER1, (void *)&arr1[i]);
    }

    for(int i = 0; i < 8; i++) 
    {
        pthread_join(pro2[i], NULL);
    }
    for(int i = 0; i < 8; i++) 
    {
        pthread_join(con2[i], NULL);
    }

    pthread_mutex_destroy(&muteX2);
    
    return 0;
}
