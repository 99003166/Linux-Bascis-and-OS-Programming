#include "stack.h"

#define Max_items2 8 // Maximum items a producer2 can produce or a consumer can consume
#define buffer_size2 8 // Size of the buffer2

int in2 = 0;
int out2 = 0;
int item2=0;
int buffer2[buffer_size2];
pthread_mutex_t mutex2;

void *producer2(void *pno2)
{   
    if(in2==buffer_size2-1)
    {
        printf("Producer Stack is full \n");
    }
    else
    {
     for(int i = 0; i < Max_items2; i++) {
        item2 = rand(); // Produce a random item2
        pthread_mutex_lock(&mutex2);
        /* put value item2 into the buffer2 */
        buffer2[in2] = item2;
        printf("Producer %d: Insert Item %d at %d\n", *((int *)pno2),buffer2[in2],in2);
        in2 = (in2 + 1) % buffer_size2;     
        pthread_mutex_unlock(&mutex2);
     }
    }
}
void *consumer(void *cno)
{   
    if(out2==buffer_size2-1)
    {
        printf("Consumer Stack is full\n");
    }
    else
    {
     int item2=0;
     for(int i = 0; i < Max_items2; i++) {
        pthread_mutex_lock(&mutex2);
        /* take one unit of data from the buffer2 */
        item2 = buffer2[out2];
        printf("Consumer %d: Remove Item %d from %d\n",*((int *)cno),item2, out2); 
        out2 = (out2 + 1) % buffer_size2;     
        pthread_mutex_unlock(&mutex2);
     }
    }
}

int main()
{   

    pthread_t pro2[8],con2[8];
    pthread_mutex_init(&mutex2, NULL);

    int a[5] = {1,2,3,4,5,6,7,8}; //Just used for numbering the producer2 and consumer

    for(int i = 0; i < 8; i++) 
    {
        pthread_create(&pro2[i], NULL, (void *)producer2, (void *)&a[i]);
    }
    for(int i = 0; i < 8; i++) 
    {
        pthread_create(&con2[i], NULL, (void *)consumer, (void *)&a[i]);
    }

    for(int i = 0; i < 8; i++) 
    {
        pthread_join(pro2[i], NULL);
    }
    for(int i = 0; i < 8; i++) 
    {
        pthread_join(con2[i], NULL);
    }

    pthread_mutex_destroy(&mutex2);

    return 0;
}
