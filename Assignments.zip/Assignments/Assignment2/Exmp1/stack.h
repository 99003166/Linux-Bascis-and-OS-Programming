#ifndef __STACKSEMAPHORES_H
#define __STACKSEMAPHORES_H

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>

void stack();

#endif
