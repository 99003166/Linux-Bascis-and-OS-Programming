#include "stack.h"

#define max_Items 8
#define buffer_Size 8

sem_t emPty1;
sem_t Full1;
int in1 = 0;
int out1 = 0;
int item2 = 0;
int buffer2[buffer_Size];

void *proDucer2(void *pno2)
 {
  if (in1 == buffer_Size - 1) 
  {
    printf("Producer stack is full \n");
  } 
  else {
    for (int i = 0; i < max_Items; i++) {
      item2 = rand();
      sem_wait(&emPty1);
      buffer2[in1] = item2;
      printf("Producer %d: Insert Item %d at %d\n", *((int *)pno2), buffer2[in1],
             in1);
      in1 = (in1 + 1) % buffer_Size;
      sem_post(&Full1);
    }
  }
}

void *consumer2(void *cno2)
 {
  if (out1 == buffer_Size - 1)
  {
    printf("Consumer stack is full\n");
  } 
  else {
    int item2 = 0;
    for (int i = 0; i < max_Items; i++) 
    {
      sem_wait(&Full1);
      item2 = buffer2[out1];
      printf("Consumer %d: Remove Item %d from %d\n", *((int *)cno2), item2, out1);
      out1 = (out1 + 1) % buffer_Size;
      sem_post(&emPty1);
    }
  }
}

void main() {
  pthread_t pro2[8], con2[8];
  sem_init(&emPty1, 0, buffer_Size);
  sem_init(&Full1, 0, 0);

  int arr1[5] = {1,2,3,4,5,6,7,8}; 

  for (int i = 0; i < 8; i++) {
    pthread_create(&pro2[i], NULL, (void *)proDucer2, (void *)&arr1[i]);
  }
  for (int i = 0; i < 8; i++) {
    pthread_create(&con2[i], NULL, (void *)consumer2, (void *)&arr1[i]);
  }

  for (int i = 0; i < 8; i++) {
    pthread_join(pro2[i], NULL);
  }
  for (int i = 0; i < 8; i++) {
    pthread_join(con2[i], NULL);
  }

  sem_destroy(&emPty1);
  sem_destroy(&Full1);
}
