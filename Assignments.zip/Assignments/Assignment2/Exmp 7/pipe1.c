#include "pipeheader.h"

void main() 
{
    char string1[256]="startofpiping"; 
    int fifo_writing,fifo_reading; 
    while(strcmp(string1,"end")!=0)   
    {   
        fifo_writing= open("PIPE_1",O_WRONLY);   
        if(fifo_writing<0)     
            printf("\nError while opening the pipe");   
        else     
        {
            printf("CHAT1= ");     
            scanf("%s",string1);     
            write(fifo_writing,string1,255*sizeof(char));     
            close(fifo_writing);     
        }   
        fifo_reading=open("PIPE_2",O_RDONLY);   
        if(fifo_reading<0)     
            printf("\nError while opening the write pipe");   
        else     
        {     
            read(fifo_reading,string1,255*sizeof(char));     
            close(fifo_reading);     
            printf("\n%s",string1);   
        }   
    } 
}
