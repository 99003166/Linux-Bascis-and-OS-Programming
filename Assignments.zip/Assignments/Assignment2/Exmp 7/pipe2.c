#include "pipeheader.h"

void main() 
{
    char string1[256]="startofpiping"; 
    int fifo_write,fifo_read; 
    while(strcmp(string1,"end")!=0)   
    {   
        fifo_write= open("PIPE_1",O_WRONLY);   
        if(fifo_write<0)     
            printf("\nError while opening the pipe");   
        else     
        {     
            printf("CHAT2= ");     
            scanf("%s",string1);     
            write(fifo_write,string1,255*sizeof(char));     
            close(fifo_write);     
        }   
        fifo_read=open("PIPE_2",O_RDONLY);   
        if(fifo_read<0)     
            printf("\nError while opening the write pipe");   
        else     
        {     
            read(fifo_read,string1,255*sizeof(char));     
            close(fifo_read);     
            printf("\n%s",string1);     
        }   
    }
} 
