#include "pipeheader.h"

void main() 
{
    int temp1;
    int temp2;
    temp1 = mkfifo("PIPE_1",0666);
    if(temp1<0)
    {
        printf("\nPIPE_1 is not created");
    }
    else
    {
        printf("\nPIPE_1 is created");
    }
    temp2 = mkfifo("PIPE_2",0666);
    if(temp2<0)
    {
        printf("\nPIPE_2 is not created");
    }
    else
    {
        printf("\nPIPE_2 is created\n");
    }
}
