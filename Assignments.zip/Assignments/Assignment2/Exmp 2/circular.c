#include "circular.h"

#define Max_Items2 8 // Maximum items a procuDer1 can produce or a consumer1 can consume
#define buffer_size3 8 // Size of the Buffer1

sem_t emPty2;
sem_t full2;
int in2 = 0;
int out2 = 0;
int Buffer1[buffer_size3];
pthread_mutex_t muTex;

void *procuDer1(void *pno1)
{   
    int item2;
    for(int i = 0; i < Max_Items2; i++) {
        item2 = rand(); // Produce a random item2
        sem_wait(&emPty2);
        pthread_mutex_lock(&muTex);
        /* wait for space in2 Buffer1 */
        while (((in2 + 1) % buffer_size3) == out2)
        {
        /* put value item2 into the Buffer1 */
           Buffer1[in2] = item2;
           printf("Producer %d: Insert Item %d at %d\n", *((int *)pno1),Buffer1[in2],in2);
           in2 = (in2 + 1) % buffer_size3;     
        }
        pthread_mutex_unlock(&muTex);
        sem_post(&full2);
    }
}
void *consumer1(void *cno2)
{   
    int item2=0;
    for(int i = 0; i < Max_Items2; i++) {
        sem_wait(&full2);
        pthread_mutex_lock(&muTex);
        /* wait for Buffer1 to fill */
        while (in2 == out2) 
        {
        /* take one unit of data from the Buffer1 */
           item2 = Buffer1[out2];
           printf("Consumer %d: Remove Item %d from %d\n",*((int *)cno2),item2, out2); 
           out2 = (out2 + 1) % buffer_size3;     
        }
        pthread_mutex_unlock(&muTex);
        sem_post(&emPty2);
    }
}

int main()
{   

    pthread_t pro2[8],con2[8];
    pthread_mutex_init(&muTex, NULL);
    sem_init(&emPty2,0,buffer_size3);
    sem_init(&full2,0,0);

    int a[5] = {12,24,34,56,34,45,23,78}; //Just used for numbering the procuDer1 and consumer1

    for(int i = 0; i < 8; i++) {
        pthread_create(&pro2[i], NULL, (void *)procuDer1, (void *)&a[i]);
    }
    for(int i = 0; i < 8; i++) {
        pthread_create(&con2[i], NULL, (void *)consumer1, (void *)&a[i]);
    }

    for(int i = 0; i < 8; i++) {
        pthread_join(pro2[i], NULL);
    }
    for(int i = 0; i < 8; i++) {
        pthread_join(con2[i], NULL);
    }

    pthread_mutex_destroy(&muTex);
    sem_destroy(&emPty2);
    sem_destroy(&full2);

    return 0;
}
