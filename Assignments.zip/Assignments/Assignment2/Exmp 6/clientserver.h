#ifndef __SERVERCLIENT_H
#define __SERVERCLIENT_H


#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include<mqueue.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>

#endif
