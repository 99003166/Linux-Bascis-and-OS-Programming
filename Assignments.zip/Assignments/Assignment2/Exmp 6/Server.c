#include "clientserver.h"

int main()
{
	int retur,bytes_num;
	struct mq_attr attr1;
	struct stat sb1;
	attr1.mq_msgsize=256;
	attr1.mq_maxmsg=10;
	mqd_t msgqid;

	msgqid=mq_open("/msgque",O_CREAT | O_RDWR,0666,&attr1); /* To create message queue*/
	if(msgqid<0)
	{
		perror("msgq_open");
		exit(1);
	}

	char buff1[20];
	int max_length=256,priori;
	
	printf("Waiting for client to send message....\n"); 
	bytes_num=mq_receive(msgqid,buff1,1024,&priori); /* To receive a message*/ 
	if(bytes_num<0)
	{
		perror("msgq_recv");
		exit(2);
	}
	
	lstat(buff1, &sb1); /* To get attributes*/

	retur = mq_send(msgqid,(const char *)&sb1,sizeof(sb1),100); /* To send attribute*/
	if(retur < 0)
	{
		perror("msgq_send");
		exit(2);
	}
	mq_close(msgqid);/* To close queue*/

	return 0;
}

