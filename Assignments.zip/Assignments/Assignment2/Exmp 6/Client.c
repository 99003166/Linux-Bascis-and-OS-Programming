#include "clientserver.h"

int main() {
  int retur, bytes_num;
  mqd_t msgqid;
  struct mq_attr attri;
  struct stat sb;
  attri.mq_msgsize = 256;
  attri.mq_maxmsg = 10;

  msgqid = mq_open("/msgque", O_CREAT | O_RDWR, 0666, &attri); /* To create message queue*/
  if (msgqid < 0) {
    perror("msgq_open");
    exit(1);
  }

  char strin[20] = "hellow.c";

  retur = mq_send(msgqid, strin, 20, 5); /* To send file name */
  if (retur < 0) {
    perror("msgq_send");
    exit(2);
  }

  int max_lengt = 256, priori;

  bytes_num = mq_receive(msgqid, (char *)&sb, 1024, &priori); /*To receive the message through queue from server*/
  if (bytes_num < 0) {
    perror("msgq_recv");
    exit(2);
  }
  /* To print file attributes*/
  printf("ID of device = %ld\n", (long)sb.st_dev);
  printf("Inode number = %ld\n", (long)sb.st_ino);
  printf("File type");
  switch (sb.st_mode & S_IFMT) {
  case S_IFBLK:
    printf("Block device\n");
    break;
  case S_IFCHR:
    printf("Character device\n");
    break;
  case S_IFDIR:
    printf("Directory\n");
    break;
  case S_IFIFO:
    printf("FIFO/pipe\n");
    break;
  case S_IFLNK:
    printf("Symlink\n");
    break;
  case S_IFREG:
    printf("Regular file\n");
    break;
  case S_IFSOCK:
    printf("Socket\n");
    break;
  default:
    printf("Unknown?\n");
    break;
  }
  printf("Mode                            = %lo (octal)\n", (unsigned long)sb.st_mode);
  printf("Link count                      = %ld\n", (long)sb.st_nlink);
  printf("User ID                         = %ld\n" , (long)sb.st_uid);
  printf("Group ID                        = %ld\n", (long)sb.st_gid);
  printf("Blocksize                       = %ld bytes\n", (long)sb.st_blksize);
  printf("File size                       = %lld bytes\n", (long long)sb.st_size);
  printf("Number of 512B Blocks allocated = %lld\n", (long long)sb.st_blocks);
  printf("Last status change              = %s", ctime(&sb.st_ctime));
  printf("Last file access                = %s", ctime(&sb.st_atime));
  printf("Last file modification          = %s", ctime(&sb.st_mtime));

  mq_close(msgqid); /* To close queue*/

  return 0;
}
