#ifndef __SERVERCLIENT_H
#define __SERVERCLIENT_H

#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<mqueue.h>
#include<fcntl.h>
#include<stdio.h>


#endif
