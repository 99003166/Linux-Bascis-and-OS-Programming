#include "clientserver.h"

int main()
{
	int retur, bytes_num;
	mqd_t msqid;
	struct mq_attr attr1;
	attr1.mq_msgsize=256;
	attr1.mq_maxmsg=15;
	
	msqid=mq_open("/msgque",O_CREAT | O_RDWR,0666,&attr1);/*CREATING A MESSAGE QUEUE IN CLIENT PROCESS*/
	if(msqid<0)
	{
		perror("msgq_open");
		exit(1);
	}

	char str[20] = "Send msg"; /*Sending a message to queue*/
	retur=mq_send(msqid,str,20,5);
	
	if(retur<0)
	{
		perror("msgq_send");
		exit(2);
	}

	char buff[8192];
	int maxlength=256,priori; /*Reciving the message through queue from the server*/
	bytes_num=mq_receive(msqid,buff,maxlength,&priori);
	if(bytes_num<0)
	{
		perror("msgq_recv");
		exit(2);
	}
	buff[bytes_num]='\0';
	printf("Message fron the server = %s\n",buff);

	mq_close(msqid); /*To close the queue*/

	return 0;
}

