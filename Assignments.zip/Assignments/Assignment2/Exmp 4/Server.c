#include "clientserver.h"

int main()
{
	int retur,buytes_num;
	struct mq_attr attri;
	attri.mq_msgsize=256;
	attri.mq_maxmsg=10;
	mqd_t msqid;

	msqid=mq_open("/msgque",O_CREAT | O_RDWR,0666,&attri); /*CREATING A MESSAGE QUEUE IN CLIENT PROCESS*/
	if(msqid<0)
	{
		perror("msgq_open");
		exit(1);
	}

	char buff[7245];
	int maxlengt=256,priori;

	printf("waiting for client to send message....\n");
	buytes_num=mq_receive(msqid,buff,maxlengt,&priori);  /*Receiving a message from queue*/
	if(buytes_num<0)
	{
		perror("msgq_recv");
		exit(2);
	}
	buff[buytes_num]='\0';
	printf("msg from client : %s\n",buff);

	
	for (int j=0; buff[j]!='\0'; j++) /*To toggle*/
    	{
        if (buff[j]>='A' && buff[j]<='Z')
            buff[j] = buff[j] + 'a' - 'A';
        else if (buff[j]>='a' && buff[j]<='z')
            buff[j] = buff[j] + 'A' - 'a';
    	}

	retur = mq_send(msqid,buff,100,100); /*To send back the message through queue from client*/
	if(retur < 0)
	{
		perror("msgq_send");
		exit(2);
	}

	mq_close(msqid); /*To close the queue*/
	return 0;
}

