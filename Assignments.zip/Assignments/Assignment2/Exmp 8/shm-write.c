#include "shmheader.h"

int main()
{
	int file_temp=4096; 
	int fd2,offset_val=0;
	sem_t *ps2,*qs2;
	ps2=sem_open("/s1",O_CREAT, 0777, 1);
	qs2=sem_open("/s2",O_CREAT, 0777, 0);
	fd2=shm_open("/shm1",O_CREAT|O_RDWR,0666);
	if(fd2<0)
	{
		perror("open");
		exit(1);
	}
        ftruncate(fd2, file_temp);
	void *pbase_val;
	pbase_val=mmap(0,file_temp, PROT_WRITE, MAP_SHARED,fd2,offset_val);
	if(pbase_val==MAP_FAILED)
	{
		fprintf(stderr,"mapping not done\n");
		exit(1);
	}
	char buff1[64];
    	char string1[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
   	sem_wait(ps2);
	strncpy(pbase_val,string1,20);	
	sem_post(ps2);
	sem_post(qs2);
	printf("buffer=%s\n",string1);
	munmap(pbase_val,file_temp);
	return 0;
}
