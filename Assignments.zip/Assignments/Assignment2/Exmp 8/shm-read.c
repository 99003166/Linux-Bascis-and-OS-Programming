#include "shmheader.h"

int main()
{
	int file_temp=4096; 
	int fd2,offset_val=0;
	fd2=shm_open("/shm1",O_CREAT|O_RDWR,0666);
	if(fd2<0)
	{
		perror("open");
		exit(1);
	}
    	ftruncate(fd2, file_temp);
	void *pbase_val;
	pbase_val=mmap(0,file_temp, PROT_READ, MAP_SHARED,fd2,offset_val);
	if(pbase_val==MAP_FAILED)
	{
		fprintf(stderr,"mapping not done\n");
		exit(1);
	}
	sem_t *ps2,*qs2;
	ps2=sem_open("/s1",O_CREAT, 0777, 1);
	qs2=sem_open("/s2",O_CREAT, 0777, 0);
	char buff1[64];
	sem_wait(qs2);
	sem_wait(ps2);
        strncpy(buff1,pbase_val,10);
	printf("buff1=%s\n",buff1);
	strcpy(buff1,pbase_val+10);
	printf("buff1=%s\n",buff1);
	 sem_post(ps2);
	sem_unlink("s1");
	sem_unlink("s2");
	munmap(pbase_val,file_temp);
	return 0;
}
		









