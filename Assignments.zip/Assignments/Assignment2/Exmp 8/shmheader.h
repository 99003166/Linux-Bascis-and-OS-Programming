#ifndef __SHM_H
#define __SHM_H

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/mman.h>
#include<sys/shm.h>
#include<semaphore.h>
#include<fcntl.h>

#endif
