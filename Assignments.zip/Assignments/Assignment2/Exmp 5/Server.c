#include "clientserver.h"

int main()
{
	int retur;
	mqd_t msgqid3;
	struct mq_attr attr;
	attr.mq_msgsize=256;
	attr.mq_maxmsg=10;

	msgqid3=mq_open("/mque1",O_WRONLY|O_CREAT,0666,&attr);/* To open a mesage queue*/
	if(msgqid3<0)
	{
		perror("msgq_open");
		exit(1);
	}
	char string1[]="temporary.c";
	int lengt=strlen(string1);
	retur=mq_send(msgqid3,string1,lengt+1,5);
	if(retur<0)
	{
		perror("msgq_send");
		exit(2);
	}
	mq_close(msgqid3);
	return 0;
}
