#include "clientserver.h"

int main()
{
	int retur,bytes_num;
	struct mq_attr attri;
	attri.mq_msgsize=256;
	attri.mq_maxmsg=10;
	mqd_t msgqid3;

	msgqid3=mq_open("/msgque1",O_RDONLY|O_CREAT,0666,&attri); /*To open a message queue */
	if(msgqid3<0)
	{
		perror("msgq_open");
		exit(1);
	}
	char buff[7245];
	int maxleng=256,priori;
	bytes_num=mq_receive(msgqid3,buff,maxleng,&priori);
	if(bytes_num<0)
	{
		perror("msgq_recv");
		exit(2);
	}
	buff[bytes_num]='\0';
	int temp;
  	printf("%s",buff);
	
	temp=execlp("/bin/gcc","gcc",buff,0);
    	if(temp<0)
		{
			perror("execlp");
			exit(1);
		}
		exit(5);
		
	printf("receive messsage:%s,bytes number=%d,priority=%d\n",buff,bytes_num,priori);
	mq_close(msgqid3);
	return 0;
}

