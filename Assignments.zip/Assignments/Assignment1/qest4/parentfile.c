#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

int main ()
{
    int pid_num;
    int statu, retrn;
    char *my_arg [] = { NULL };
    char *my_en [] = { NULL };

    printf ("Hello Parent\n");

    pid_num = fork ();

    if (pid_num == 0)
    {
      execl ("child", *my_arg,  *my_en, NULL); //This is Child
    }

    printf ("Waiting for Child to complete.\n");

    if ((retrn = waitpid (pid_num, &statu, 0)) == -1)
         printf ("error:parent\n");

    if (retrn == pid_num)
        printf ("Child process waiting for:\n");
}
