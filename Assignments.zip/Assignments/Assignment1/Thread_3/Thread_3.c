#include <time.h>
#include <stdio.h>
 
int main()
{
    time_t time_up= time(NULL);
    struct  tm1 tm1 = *localtime(&time_up);
    
    printf("Current Time is = %02d:%02d:%02d\n",tm1.tm_hour, tm1.tm_min, tm1.tm_sec);
    return 0;
}
