#include "fun.h"
int mul(int s, int d) {
  return c * d;
}
