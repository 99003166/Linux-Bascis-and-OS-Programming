#include "fun.h"
#include <stdio.h>
int main() {
  int op1, op2, op3, op4;
  op1 = 10;
  op2 = 20;
  op3 = mul(op1, op2);
  op4 = cube(op1);
  printf("op3=%op4,op4=%op4\n",op3,op4);
  return 0;
}
