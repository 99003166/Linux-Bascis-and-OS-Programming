#include "fun.h"
int cube(int y) {
return y * y * y;
}
