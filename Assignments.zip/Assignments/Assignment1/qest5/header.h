#ifndef __FUN_H
#define __FUN_H
int mul(int s, int d);
int cube(int y);
#endif
