#include <signal.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <sys/types.h> 
#include <unistd.h> 


// function declaration 
void sig_up1(); 
void sig_int1(); 
void sig_quit1(); 

// driver code 
void main() 
{ 
    int process_id; 
  
    if ((process_id = fork()) < 0) { 
        perror("fork"); 
        exit(1); 
    } 

    if (process_id == 0) /*Child condition*/
    { 
        signal(SIGHUP, sig_up1); 
        signal(SIGINT, sig_int1); 
        signal(SIGQUIT, sig_quit1); 
        for (;;) /*Infinite loop*/
            ; 
    } 

    else /* parent condition*/
    { 
        printf("\nSending of SIGHUP singal by PARENT\n\n"); 
        kill(process_id, SIGHUP); 
  
        sleep(3); /* 3 second sleep */
        printf("\nSending of SIGINT singal by PARENT\n\n"); 
        kill(process_id, SIGINT); 
  
        sleep(3); /*3 second sleep */
        printf("\nSending of SIGQUIT singal by PARENT\n\n"); 
        kill(process_id, SIGQUIT); 
        sleep(3); 
    } 
} 
// function definition of sig_int1() 
void sig_int1() 
  
{ 
    signal(SIGINT, sig_int1); /* reset signal */
    printf("SIGINT signal recived by CHILDREN\n"); 
} 
  
// function definition of sig_up1() 
void sig_up1() 
  
{ 
    signal(SIGHUP, sig_up1); 
    printf("SIGHUP signal recived by CHILDREN\n"); 
} 
 

//function definition of  sig_quit1() 
void sig_quit1() 
{ 
    printf("Child Died\n"); 
    exit(0); 
} 

