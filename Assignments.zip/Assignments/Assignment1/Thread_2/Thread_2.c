#include <stdio.h> 
#include <pthread.h> 
#include <stdlib.h> 


#define multi 5  
#define mAx_val 20   


int max_num[multi] = { 0 }; 
int thread_num = 0; 

int num[mAx_val] = { 12,15,45,16,78,95,45,74,32,65,
		  425,564,41,46,44,56,85,123,45,20}; 

void maximum_func(void* arg) 
{ 
    int j, numb = thread_num++; 
    int maxi = 0; 
  
    for (j = numb * (mAx_val / 4); j < (numb + 1) * (mAx_val / 4); j++) { 
        if (num[j] > maxi) 
            maxi = num[j]; 
    } 
  
    max_num[numb] = maxi; 
} 

int main() 
{ 
    int maxi = 0; 
    int j; 
    pthread_t Pthreads[multi]; 

    for (j = 0; j < multi; j++) /*Creating Pthreads*/
        pthread_create(&Pthreads[j], NULL,maximum_func, (void*)NULL); 

    for (j = 0; j < multi; j++) 
        pthread_join(Pthreads[j], NULL); 

    for (j = 0; j < multi; j++) { 
        if (max_num[j] > maxi) 
            maxi = max_num[j]; 
    } 

    printf("Maximum number is = %d", maxi); 
    return 0; 
} 
