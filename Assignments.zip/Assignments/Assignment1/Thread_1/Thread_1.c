#include<stdio.h>
#include <pthread.h> 
#define thread_maxval 10 
#define max_val 1000 


int a[max_val];


int total_sum[10] = { 0 }; 
int prt = 0; 
  
void* sum_arr(void* argum) 
{  	int thread_pt = prt++;
 
      for(int i = thread_pt * (max_val / 10); i < (thread_pt + 1) * (max_val / 10); i++)
	{
		a[i]=1;
	}

      for (int i = thread_pt * (max_val / 10); i < (thread_pt + 1) * (max_val / 10); i++) 
      	total_sum[thread_pt] += a[i]; 
        	

} 

int main() 
{ 
    int total_sum = 0; 
  
    pthread_t threads[thread_maxval]; 
   
    for (int i = 0; i < thread_maxval; i++) 
    {
        pthread_create(&threads[i], NULL, sum_arr, (void*)NULL); 
    }
    
    for (int i = 0; i < thread_maxval; i++) 
    {    
    	pthread_join(threads[i], NULL); 
    }
     
  
    for (int i = 0; i < thread_maxval; i++) 
    {
        total_sum += total_sum[i]; 
    }
    
    printf("Total sum is = %d\n",total_sum);
    return 0; 
} 
